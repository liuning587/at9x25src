/**
 ** DIY9X25_KEY驱动程序v1.0
 ** 此版本只提供简单的读写接口
 **  Author: LiuNing
 **  Date:   2014-08-01
 **/
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/init.h>
#include <linux/platform_device.h>
#include <linux/errno.h>
#include <linux/device.h>
#include <linux/delay.h> 
#include <linux/uaccess.h>
#include <linux/miscdevice.h>

#include <asm/irq.h>
#include <mach/irqs.h>
#include <mach/io.h>
#include <mach/gpio.h>
#include <mach/at91_pio.h>
#include <mach/at91_pmc.h>
#include <mach/hardware.h>

#define DEVICE_NAME        "key"
#define GPIO_MAJOR            235

#define GPIO_OUT_0              0
#define GPIO_OUT_1              1
#define GPIO_PULLUP_0           0 
#define GPIO_PULLUP_1           1

#define DIY9X25_KEY_PIN    AT91_PIN_PB11   /**< 定义引脚 */

#if 0
static void set_pin_high(void)
{
    at91_set_gpio_output(DIY9X25_KEY_PIN, GPIO_OUT_1);
}

static void set_pin_low(void)
{
    at91_set_gpio_output(DIY9X25_KEY_PIN, GPIO_OUT_0);
} 
#endif

static void set_pin_input(void)
{
    at91_set_gpio_input(DIY9X25_KEY_PIN, GPIO_PULLUP_0);
}

static char set_pin_get(void)
{
    if (at91_get_gpio_value(DIY9X25_KEY_PIN))
        return 1;
    else
        return 0;
}

static ssize_t key_read ( struct file* filp, char __user* buf, size_t count, loff_t* f_pos )
{
    unsigned char i;
    char tempBuf;

    do
    {
        tempBuf = set_pin_get();
    } while (tempBuf != set_pin_get());
    
	copy_to_user(buf, &tempBuf, 1);
	
    for (i = 0; i < 5; i++)

    return 1;
}


static struct file_operations dev_fops = {
    .owner = THIS_MODULE,
    .read = key_read,
    };

static struct miscdevice misc = {
    .minor = MISC_DYNAMIC_MINOR,
    .name = DEVICE_NAME,
    .fops = &dev_fops,
    };

static int __init DIY9X25_KEY_init_module ( void )
{
    int ret;

    set_pin_input();
    ret = misc_register(&misc);
    printk (DEVICE_NAME"\tinitialized\n");
    return ret;
}

static void __exit DIY9X25_KEY_exit_module ( void )
{
    misc_deregister(&misc);
}

module_init(DIY9X25_KEY_init_module);
module_exit(DIY9X25_KEY_exit_module);

MODULE_AUTHOR("ln587");
MODULE_DESCRIPTION("DIY9X25 KEY Driver");
MODULE_LICENSE("GPL");